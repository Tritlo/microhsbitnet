-- | Shared forward pass: build the layer stack, run a token-id sequence through
-- it, and take the LM-head argmax. Used by M3 (single forward) and M4 (generation).
-- No KV cache — each call reprocesses the whole sequence (fine for short demos).
module Forward
  ( look
  , mkLin
  , mkNorm
  , mkNormBS
  , buildLayers
  , finalHidden
  , argmaxLogits
  , emptyCaches
  , stepLayers
  , buildLayersC
  , forceLayersC
  , emptyCachesC
  , stepLayersC
  , cVocab
  ) where

import qualified Data.ByteString as BS
import Data.List (foldl')
import Safetensors (Tensor(..), lookupTensor, bf16At)
import Loader (slice)
import Model
import Dot (argmaxBf16, packF32, decodeBf16)

cVocab :: Int
cVocab = 128256

look :: [Tensor] -> String -> Tensor
look ts name = case lookupTensor name ts of
  Just t  -> t
  Nothing -> error ("missing tensor: " ++ name)

mkLin :: [Tensor] -> BS.ByteString -> String -> Lin
mkLin ts dat name =
  let wt = look ts (name ++ ".weight")
      st = look ts (name ++ ".weight_scale")
      [packedRows, inD] = tShape wt
  in Lin (slice dat wt) inD (packedRows * 4) (bf16At (slice dat st) 0)

mkNorm :: [Tensor] -> BS.ByteString -> String -> [Float]
mkNorm ts dat name =
  let t = look ts name
      d = head (tShape t)
      b = slice dat t
  in [ bf16At b (2 * c) | c <- [0 .. d - 1] ]

-- | A norm weight decoded bf16->f32 straight to a byte buffer in C (the C-path
-- equivalent of @packF32 . mkNorm@, but without the per-element Haskell decode).
mkNormBS :: [Tensor] -> BS.ByteString -> String -> BS.ByteString
mkNormBS ts dat name =
  let t = look ts name
      d = head (tShape t)
  in decodeBf16 (slice dat t) d

buildLayer :: [Tensor] -> BS.ByteString -> Int -> Layer
buildLayer ts dat i =
  let p = "model.layers." ++ show i ++ "."
  in Layer
       (mkNorm ts dat (p ++ "input_layernorm.weight"))
       (mkLin ts dat (p ++ "self_attn.q_proj"))
       (mkLin ts dat (p ++ "self_attn.k_proj"))
       (mkLin ts dat (p ++ "self_attn.v_proj"))
       (mkNorm ts dat (p ++ "self_attn.attn_sub_norm.weight"))
       (mkLin ts dat (p ++ "self_attn.o_proj"))
       (mkNorm ts dat (p ++ "post_attention_layernorm.weight"))
       (mkLin ts dat (p ++ "mlp.gate_proj"))
       (mkLin ts dat (p ++ "mlp.up_proj"))
       (mkNorm ts dat (p ++ "mlp.ffn_sub_norm.weight"))
       (mkLin ts dat (p ++ "mlp.down_proj"))

-- | Build all @n@ decoder layers.
buildLayers :: [Tensor] -> BS.ByteString -> Int -> [Layer]
buildLayers ts dat n = [ buildLayer ts dat i | i <- [0 .. n - 1] ]

-- A C-path layer: same weights, but the RMSNorm weights are float32 byte buffers.
buildLayerC :: [Tensor] -> BS.ByteString -> Int -> LayerC
buildLayerC ts dat i =
  let p        = "model.layers." ++ show i ++ "."
      normBS n = mkNormBS ts dat (p ++ n)
  in LayerC
       (normBS "input_layernorm.weight")
       (mkLin ts dat (p ++ "self_attn.q_proj"))
       (mkLin ts dat (p ++ "self_attn.k_proj"))
       (mkLin ts dat (p ++ "self_attn.v_proj"))
       (normBS "self_attn.attn_sub_norm.weight")
       (mkLin ts dat (p ++ "self_attn.o_proj"))
       (normBS "post_attention_layernorm.weight")
       (mkLin ts dat (p ++ "mlp.gate_proj"))
       (mkLin ts dat (p ++ "mlp.up_proj"))
       (normBS "mlp.ffn_sub_norm.weight")
       (mkLin ts dat (p ++ "mlp.down_proj"))

-- | Build all @n@ decoder layers for the C generation path.
buildLayersC :: [Tensor] -> BS.ByteString -> Int -> [LayerC]
buildLayersC ts dat n = [ buildLayerC ts dat i | i <- [0 .. n - 1] ]

-- | Force every byte buffer of the built layers (their total size). Used to
-- separate one-time weight setup (the norm bf16->f32 decode) from prefill timing.
forceLayersC :: [LayerC] -> Int
forceLayersC = foldl' (\ acc l -> acc + layerBytes l) 0
  where
    linBytes (Lin p _ _ _) = BS.length p
    layerBytes (LayerC n1 q k v n2 o n3 g u n4 d) =
      BS.length n1 + BS.length n2 + BS.length n3 + BS.length n4
        + linBytes q + linBytes k + linBytes v + linBytes o
        + linBytes g + linBytes u + linBytes d

-- Deeply force a sequence of vectors so the layer fold can't build a giant thunk.
forceSeq :: [[Float]] -> [[Float]]
forceSeq xss = outer xss `seq` xss
  where
    outer []          = ()
    outer (xs : rest) = inner xs `seq` outer rest
    inner []          = ()
    inner (x : xs)    = x `seq` inner xs

-- | Run token ids through embed + all layers + final norm, returning the final
-- (normed) hidden state of the last position.
finalHidden :: [Layer] -> [Float] -> BS.ByteString -> [Int] -> [Float]
finalHidden layers normW embedB ids =
  let xs0 = map (embedRow embedB) ids
      fh  = foldl' (\xs l -> forceSeq (decoderLayer l xs)) xs0 layers
  in rmsNorm normW (last fh)

-- | Empty KV caches for @n@ layers.
emptyCaches :: Int -> [KVCache]
emptyCaches n = replicate n ([], [])

forceVec :: [Float] -> ()
forceVec []       = ()
forceVec (x : xs) = x `seq` forceVec xs

-- | Thread one new token (at position @pos@) through all layers with a KV cache,
-- returning its final hidden and the updated caches. Each layer's hidden is forced
-- (which also forces the new cache entry, used in this step's attention) to keep
-- generation's memory flat.
stepLayers :: [Layer] -> Int -> [KVCache] -> [Float] -> ([Float], [KVCache])
stepLayers layers pos caches x0 = go layers caches x0 []
  where
    go (l : ls) (c : cs) h acc =
      let (h', c') = decoderStep pos l c h
      in forceVec h' `seq` go ls cs h' (c' : acc)
    go _ _ h acc = (h, reverse acc)

-- | Empty C-path KV caches for @n@ layers (seeded by the first token).
emptyCachesC :: Int -> [KVC]
emptyCachesC n = replicate n Nothing

-- | Thread one new token (at @pos@) through all layers on float32 byte buffers
-- via the C kernels. Each layer's output buffer is forced to keep memory flat.
stepLayersC :: [LayerC] -> Int -> [KVC] -> BS.ByteString -> (BS.ByteString, [KVC])
stepLayersC layers pos caches x0 = go layers caches x0 []
  where
    go (l : ls) (c : cs) h acc =
      let (h', c') = decoderStepC l pos c h
      in BS.length h' `seq` go ls cs h' (c' : acc)
    go _ _ h acc = (h, reverse acc)

-- | The argmax token over the tied LM head for a final hidden vector, with its
-- logit. The whole vocab scan runs in the C kernel (one FFI call).
argmaxLogits :: BS.ByteString -> [Float] -> (Int, Float)
argmaxLogits embedB hLast = argmaxBf16 embedB hLast cHidden cVocab
